package Map;

import java.util.*;
import java.util.List;

public class BoardRepository {
	// 데이터를 저장하는 클래스
	private Map<String, BoardDTO> map = new HashMap<>();
	BoardDTO boardDTO = new BoardDTO();

	public boolean save(String bno, BoardDTO boardDTO) {
		if (map.put(bno, boardDTO) == null) {
			return true;
		} else {
			return false;
		}
	}

	public Map<String, BoardDTO> findAll() {
		return map;
	}

	public BoardDTO findById(String bno) {
		for (String Bno : map.keySet()) {
			if (map.get(Bno).getBno().equals(bno)) {
				return map.get(bno);
			}
		}
		return null;
	}

	public boolean update(BoardDTO boardDTO, String bno) {
		for (String Bno : map.keySet()) {
			if (map.get(Bno).getBno().equals(bno)) {
				map.get(Bno).setTitle(boardDTO.getTitle());
				map.get(Bno).setWriter(boardDTO.getWriter());
				return true;
			}
		}
		return false;
	}

	public boolean delete(String bno) {
		for (String Bno : map.keySet()) {
			if (map.get(Bno).getBno().equals(bno)) {
				map.remove(Bno);
				return true;
			}
		}
		return false;
	}
}
